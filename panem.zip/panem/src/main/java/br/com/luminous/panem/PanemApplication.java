package br.com.luminous.panem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanemApplication.class, args);
	}

}
